# Malom → NMM_LLM Integration Plan
*Accessing the Gévay–Danner solved Mills database from the Sentinel overlay AI*

***

## 1. What the Malom Database Actually Is

### File naming
Every sector (work unit) is stored as an individual binary file named:
```
std_W_B_WF_BF.sec2    ← Nine Men's Morris with ultra-strong (DD) solution
```
where `W`/`B` = white/black stones on the board, `WF`/`BF` = white/black stones still to place, and the `2` suffix comes from `#define FNAME_SUFFIX "2"` when `#define DD` is active (the default for the released database).[^1]

For example, the endgame sector where white has 5 stones and black has 4 stones, all placed, is `std_5_4_0_0.sec2`. All files live flat in the database directory alongside `Wrappers.dll`.[^2]

### Entry format (non-DD / legacy)
Without the `DD` compile flag each entry is **1 byte** at index `i` (where `i` is the perfect-hash index for a position), decoded as:[^3]
```
byte value → meaning
0 .. MAX_VAL (178)            → eval_elem_sym::val, x = value
SPEC+1 .. SPEC+16 (180..195)  → eval_elem_sym::sym (symmetry pointer)
SPEC (179)                    → overflow; real value in em_set side-table
256 - count                   → eval_elem_sym::count (retrograde count)
```

### Entry format (DD / ultra-strong — what you'll actually use)
With `#define DD` (and `STONE_DIFF` off, which is the standard build) each entry is **3 bytes** (little-endian), bit-packed as:[^4][^5]
```
Bits [0 .. field2_offset-1]  = field1  (sec_val, signed, field1_size bits)
Bits [field2_offset .. 23]   = field2  (DTW-like secondary value, field2_size bits)
```
For STANDARD variant the constants are:
```c
eval_struct_size = 3          // bytes per entry
field2_offset    = 12         // field1 occupies bits 0–11 (signed 12-bit)
field1_size      = 12         // bits
field2_size      = 12         // bits (bits 12–23, signed 12-bit)
```
Both fields are **sign-extended**. An entry is decoded with `sign_extend<field1_size>` and `sign_extend<field2_size>`.[^4]

There is also an overflow side-table `em_set`: a list of `(int32, int32)` key–value pairs appended to the file after the main array. Any entry whose `field2` equals `spec_field2` (the most-negative 12-bit signed value, i.e. `−2048`) means "look up `i` in `em_set`".[^5]

### eval_elem2 semantics
An entry stores `(key1: sec_val, key2: int)`. The case is determined by `key1`:[^3][^4]
```
key1 != 0  →  Val  (game-theoretic outcome)
key1 == 0  →  Count (retrograde in-progress counter — should never appear
                      in the finished database)
```
For `Val`, `key1` is the **sector value** of the sector that *determines* this position's outcome (loaded from `std.secval`), and `key1 < 0` means the side to move **loses**, `key1 > 0` means the side to move **wins**, `key1 == virt_loss_val` means loss, `key1 == virt_win_val` means win, `key1 == 0` means draw. The secondary `key2` is a distance-to-win/loss measure (smaller = sooner).[^3][^4]

### The optional `.secval` file
For STANDARD variant with `DD` and without `STONE_DIFF`, a text file `std.secval` in the same directory stores the per-sector game-theoretic values loaded at startup. It has the format:[^5]
```
virt_loss_val: <n>
virt_win_val: <n>
unt>
W B WF BF  value
...
```

### Header
When `DD` is defined, there is a 64-byte header at the start of each `.sec2` file containing `version` (int32), `eval_struct_size` (int32), `field2_offset` (int32), and `stone_diff_flag` (char), zero-padded to 64 bytes.[^4][^5]

In the simplified (non-DD) solver the `header_size` constant is **0**, meaning the file starts immediately with the byte array.[^5]

### Perfect hash (the index into the file)
The `Hash` class maps a board position to an integer index in `[0, hash_count)`. The hash decomposes into two combinatorial functions called `f` (for white stone placements on 24 squares) and `g` (for black stone placements on the remaining squares). Lookup tables are precomputed from the board and sector `(W, B, WF, BF)`.[^6][^1]

The Wrapper exposes this: `Wrappers::Sector::hash(board)` returns `Tuple<int, gui_eval_elem2>` — the integer is the hash index, the second element is the evaluated position.[^6]

***

## 2. The MalomAPI Interface (Simplest Access Path)

`MalomAPI.dll` (VB.NET, 64-bit) exposes one static class `MalomSolutionAccess` with these entry points:[^2]

```vb
GetBestMove(whiteBitboard, blackBitboard, whiteStonesToPlace, blackStonesToPlace, playerToMove, onlyStoneTaking) → Integer
GetBestMoveNoException(...)  → Integer   ' same, never throws; 0 = error
GetLastError()               → String
GetBestMoveStr(args: String) → Integer   ' space-separated args for C++ ExecuteInDefaultAppDomain
```

**Input**: position encoded as two 24-bit bitboards (one per player) plus stone counts.  
**Output**: a move bitboard — bits set for every square that changes (piece appears on empty square, or disappears from occupied one).[^2]

The bit → board-position mapping is documented in `MalomAPI/Bitboard.png`.[^2]

**Prerequisites in the working directory**:
- All `.sec2` sector files
- `std.secval` (for DD variant)
- `Wrappers.dll`

***

## 3. Your NMM_LLM Board Representation

Your project uses a 24-label coordinate system (outer ring: `a7 d7 g7 g4 g1 d1 a1 a4`; middle: `b6 d6 f6 f4 f2 d2 b2 b4`; inner: `c5 d5 e5 e4 e3 d3 c3 c4`).[^7]

You already have `BoardState` with:
- `board.positions: dict[str, str]`  — `""`, `"W"`, or `"B"` per cell  
- `board.pieces_placed: dict[str, int]`  
- `board.turn: str` (`"W"` or `"B"`)  
- `board.to_fen_string()` for serialization[^8][^7]

Your existing `EndgameSolvedDB` in `ai/endgame_solved_db.py` already implements a pure-Python WDL lookup using your own `.wdl` files — the Malom integration is the *upstream source of truth* that can generate or validate those tables.[^8]

Your Sentinel overlay (`configs/sentinel_default.yaml`) has an `external_db_path: ""` and `external_db_enabled: false` — exactly the right hook for connecting Malom.[^9]

***

## 4. Integration Architecture

There are two viable strategies, from easiest to most powerful:

### Strategy A — Subprocess call to MalomAPI via GetBestMoveStr (quickest)
MalomAPI exposes `GetBestMoveStr(args)` specifically to support non-.NET callers via `ExecuteInDefaultAppDomain`. You can call this from Python using `subprocess` or a thin C wrapper without any .NET interop.[^2]

```
Python                                 Windows .NET runtime
  │                                         │
  │  subprocess / stdin-stdout protocol     │
  └──────► malom_bridge.exe  ──────────────► MalomAPI.dll
                                             └──► reads .sec2 files
```

A small C# bridge (`malom_bridge.cs`) reads one space-separated position per stdin line, calls `MalomSolutionAccess.GetBestMoveStr()`, and writes the result to stdout. Python wraps it with `subprocess.Popen`.

**Pros**: zero Python binary parsing, uses the official API.  
**Cons**: Windows-only (MalomAPI is 64-bit Windows .NET), subprocess overhead (~10–50 ms/call).

### Strategy B — Pure Python binary reader (Linux / cross-platform)
Implement the Malom format directly in Python, bypassing the DLL. This is the right approach for Linux (your Pop!_OS dev machine) and for batch generation of training data.[^1][^4][^5]

```
Python MalomReader
  ├── board → bitboard()        # coordinate label → 24-bit int
  ├── bitboard_to_pieces()      # inverse
  ├── sector_id(W, B, WF, BF)  # find correct .sec2 file
  ├── Hash(W, B)                # f/g lookup tables  ← hardest part
  ├── read_sector(path)         # mmap + header parse + em_set
  └── query(board) → WDL + DTW # decode (key1, key2)
```

***

## 5. Coordinate Mapping (Bitboard ↔ Your Labels)

From `MalomAPI/Bitboard.png` and the bitboard example in the README (`131 = 1 + 2 + 128` = bits 0, 1, 7 = left-side vertical mill), the 24-bit mapping confirmed by the standard board adjacency is:

| Bit | Your label | Ring |
|-----|-----------|------|
| 0 | a7 | outer |
| 1 | d7 | outer |
| 2 | g7 | outer |
| 3 | g4 | outer |
| 4 | g1 | outer |
| 5 | d1 | outer |
| 6 | a1 | outer |
| 7 | a4 | outer |
| 8 | b6 | middle |
| 9 | d6 | middle |
| 10 | f6 | middle |
| 11 | f4 | middle |
| 12 | f2 | middle |
| 13 | d2 | middle |
| 14 | b2 | middle |
| 15 | b4 | middle |
| 16 | c5 | inner |
| 17 | d5 | inner |
| 18 | e5 | inner |
| 19 | e4 | inner |
| 20 | e3 | inner |
| 21 | d3 | inner |
| 22 | c3 | inner |
| 23 | c4 | inner |

> **Verify this mapping** against `Bitboard.png` in the repo before using it in production — the exact bit ordering matters for correctness.[^2]

```python
POSITIONS = ["a7","d7","g7","g4","g1","d1","a1","a4",
             "b6","d6","f6","f4","f2","d2","b2","b4",
             "c5","d5","e5","e4","e3","d3","c3","c4"]

def board_to_bitboards(board_state):
    wb, bb = 0, 0
    for i, pos in enumerate(POSITIONS):
        owner = board_state.positions.get(pos, "")
        if owner == "W": wb |= (1 << i)
        elif owner == "B": bb |= (1 << i)
    return wb, bb

def bitboard_to_move(before_wb, before_bb, move_bb, side):
    """Decode a Malom move bitboard into (from_pos, to_pos, removed_pos)."""
    changed = [POSITIONS[i] for i in range(24) if (move_bb >> i) & 1]
    # ... interpret changed squares against before state
```

***

## 6. Python Binary Reader for `.sec2` Files

### 6a. File structure (DD build, non-STONE_DIFF)
```
Offset 0      : int32  version          (must == 2)
Offset 4      : int32  eval_struct_size (must == 3)
Offset 8      : int32  field2_offset    (must == 12 for STANDARD)
Offset 12     : char   stone_diff_flag  (must == 0)
Offset 13–63  : zeroed padding (header_size = 64)
Offset 64     : N × 3 bytes, little-endian, N = hash_count
After array   : int32  em_set_size
                em_set_size × (int32 key, int32 val)
```


### 6b. Entry decode
```python
import struct, mmap

HEADER_SIZE = 64
EVAL_STRUCT_SIZE = 3
FIELD2_OFFSET = 12   # bits

def sign_extend(value, bits):
    sign_bit = 1 << (bits - 1)
    return (value & (sign_bit - 1)) - (value & sign_bit)

def read_entry(mm, em_set, i):
    off = HEADER_SIZE + i * EVAL_STRUCT_SIZE
    raw = mm[off:off+3]
    a = raw | (raw[^1] << 8) | (raw[^2] << 16)
    field1 = sign_extend(a & ((1 << FIELD2_OFFSET) - 1), FIELD2_OFFSET)
    field2 = sign_extend(a >> FIELD2_OFFSET, 24 - FIELD2_OFFSET)
    SPEC_FIELD2 = -(1 << (12 - 1))      # most-negative 12-bit signed = -2048
    if field2 == SPEC_FIELD2:
        field2 = em_set[i]              # overflow: use side-table
    return field1, field2               # (key1=sec_val, key2=DTW)

def decode_outcome(key1, virt_win_val, virt_loss_val):
    if key1 == virt_win_val:  return "W"
    if key1 == virt_loss_val: return "L"
    if key1 == 0:             return "D"
    return "W" if key1 > 0 else "L"    # intermediate sectors
```


### 6c. Reading the em_set
```python
def read_sector(path):
    with open(path, "rb") as f:
        data = f.read()
    # Header validation
    version, esize, f2off, sdflag = struct.unpack_from("<iiic", data, 0)
    assert version == 2 and esize == 3 and f2off == 12 and sdflag == b'\x00'
    # Hash array size: (file_size - header - em_set) / 3
    # Read em_set at the end
    # First find hash_count from the sector id's known size
    # (or infer: read until the em_set marker)
    return data, version
```

### 6d. The hard part — reimplementing the hash function
The `Hash` class in Malom builds two lookup tables `f_lookup[1<<24]` and `g_lookup` from combinatorial ranking of board positions. Rather than reimplementing this from scratch, the recommended approach is:[^6]

**Option 1 (recommended)**: call into `Wrappers.dll` / `MalomAPI.dll` to retrieve the hash index for a given board, and only do the file read in Python.

**Option 2**: port the combinatorial ranking. The hash uses the same combinatorial-number-system approach as your existing `endgame_solved_db.py` (`combo_rank`). The key insight from `sector.cpp` is:[^6][^5]
- `f(board)` ranks the positions of the W stones among all 24 squares using combinatorial ranking with symmetry factored out
- `g(board, W)` ranks the B stones on the remaining `24 - W` squares
- `hash_index = f_rank * C(24-W, B) * phase_factor + g_rank * phase_factor + phase_offset`

This is structurally identical to `encode_position_id()` in your own `endgame_solved_db.py`, extended to handle the placement phase (WF, BF > 0).[^8]

***

## 7. Where to Add This in NMM_LLM

### 7a. New file: `ai/malom_db.py`
Drop-in replacement or supplement for `ai/endgame_solved_db.py`, but with full game coverage (not just 3–7 piece endgames):

```python
class MalomDB:
    """Query interface to the Gévay–Danner Malom solved database."""
    
    def __init__(self, db_dir: str | Path, variant: str = "std"):
        self._db_dir = Path(db_dir)
        self._variant = variant
        self._secvals = self._load_secval()   # parse std.secval
        self._cache: dict[tuple, bytes] = {}  # LRU cache of loaded sectors
    
    def is_available(self) -> bool:
        return any(self._db_dir.glob(f"{self._variant}_*.sec2"))
    
    def query(self, board: BoardState) -> dict | None:
        """Return {'outcome': 'W'|'L'|'D', 'dtw': int} or None."""
        wb, bb = board_to_bitboards(board)
        wf = max(0, 9 - board.pieces_placed["W"])
        bf = max(0, 9 - board.pieces_placed["B"])
        w_count = bin(wb).count("1")
        b_count = bin(bb).count("1")
        sector_key = (w_count, b_count, wf, bf)
        fname = self._db_dir / f"{self._variant}_{w_count}_{b_count}_{wf}_{bf}.sec2"
        if not fname.exists():
            return None
        mm, em_set, hash_count = self._load_sector(fname)
        idx = self._hash(wb, bb, w_count, b_count)   # perfect hash
        if idx < 0 or idx >= hash_count:
            return None
        key1, key2 = read_entry(mm, em_set, idx)
        outcome = decode_outcome(key1, ...)
        return {"outcome": outcome, "dtw": key2}
```

### 7b. Hook into `configs/sentinel_default.yaml`
Enable the integration by setting:
```yaml
external_db_path: "/path/to/malom/database"
external_db_enabled: true
```
Your Sentinel training code already reads these fields.[^9]

### 7c. Hook into `ai/coordinator.py`
The `Coordinator.__init__` already accepts `endgame_db` and `endgame_recognizer`. Add a `malom_db` parameter alongside these and plumb it into `deliberate()`:

```python
# In Coordinator.deliberate() or the score-adjustment step:
if self.malom_db and self.malom_db.is_available():
    result = self.malom_db.query(board)
    if result:
        # override or heavily weight engine move toward Malom's WDL
        malom_outcome = result["outcome"]
        dtw = result["dtw"]
        # adjust sentinel score, log to dialogue, use for training label
```


### 7d. Use for Sentinel training labels
The Sentinel overlay trains a classifier over position states with labels like `mistake_start`, `critical_turning_point` etc. (`sentinel_default.yaml`). Malom WDL values are the ground truth for these labels:[^9]

| Malom result | Sentinel label |
|---|---|
| Position is L (side to move loses), engine plays non-L move | `mistake_start` |
| Position is W, opponent made move that turned it to L | `critical_turning_point` |
| Position is W, engine finds optimal move | `safe_continuation` |
| Position is D throughout | `neutral_state` |

This replaces the current heuristic label assignment with exact retrograde ground truth.

***

## 8. Step-by-Step Implementation Plan

### Step 1 — Verify the bitboard mapping (1 hour)
- Download the Malom binary release from the project webpage
- Load `MalomAPI.dll` in a test `.vb` or `.cs` script on Windows
- Call `GetBestMove` for a known starting position, compare the returned move bitboard against `Bitboard.png`
- Confirm the bit → label table in Section 5 above is correct[^2]

### Step 2 — Parse `.secval` and one sector header (2 hours)
Write `parse_secval(path)` and `parse_sector_header(path)` in Python, validate `version == 2`, `eval_struct_size == 3`, `field2_offset == 12`.[^4][^5]

### Step 3 — Read entries for a known position (2 hours)
Pick a trivially solved position (e.g. one side has only 2 stones on the board → immediate loss). Compute `key1, key2` from the file. Verify `decode_outcome(key1)` returns `"L"` for that side.[^5][^4]

### Step 4 — Port the hash function (4–8 hours)
This is the hardest step. Start by reading `hash.cpp` carefully, particularly the `f_lookup` and `g_lookup` construction loops. The structure mirrors your own `combo_rank` + symmetry normalization in `board_symmetry.py`. Validate by cross-checking hash indices against the MalomAPI output for 100+ positions.[^7][^6]

### Step 5 — Build `ai/malom_db.py` (2 hours)
Assemble the full `MalomDB` class with `mmap`-based sector caching, em_set support, and the `query(board)` interface matching `EndgameSolvedDB.query()`.[^8]

### Step 6 — Wire into Coordinator and Sentinel (2 hours)
- Add `malom_db: MalomDB | None` to `Coordinator.__init__`
- In the move-scoring / `deliberate()` path, query Malom and adjust scores
- In game-record saving, annotate each position with its Malom label for training
- Update `configs/sentinel_default.yaml` with `external_db_path`[^10][^9]

### Step 7 — Generate training data (hours → days depending on coverage)
Run a batch job over your existing `data/games/*.jsonl` files, looking up every position's Malom WDL and overwriting or augmenting the Sentinel labels. This gives the model exact ground-truth supervision rather than heuristic labels.

***

## 9. Key Implementation Notes

- **Memory**: Each `.sec2` sector file for the main game fits in memory comfortably (the largest sectors are tens of MB). Use `mmap.mmap` with `ACCESS_READ` for O(1) random access without loading the whole file.[^5]
- **Caching**: Cache the most recently accessed 10–20 sectors in a dict keyed by `(W, B, WF, BF)`. Most real games will stay in a small set of sectors for many consecutive moves.
- **em_set is rare**: In practice `em_set` entries are very uncommon. A quick check `if field2 == -2048` before the dict lookup adds negligible overhead.
- **Linux vs Windows**: The `.sec2` format is pure binary, endian-agnostic little-endian. The files read fine on Linux. Only `MalomAPI.dll` and `Wrappers.dll` are Windows-only.
- **Phase handling**: When `WF > 0` or `BF > 0` the position is in the placement phase. The sector file handles this natively — the hash covers all phases for a given `(W, B, WF, BF)` tuple.[^1][^5]
- **Existing `endgame_solved_db.py` can stay**: Malom covers the full game; your custom `.wdl` tables cover only 3–7 piece endgames. Keep both: use Malom when available (placement + movement phases), fall back to your own table otherwise.[^8]

---

## References

1. [Introducing Weasel for Database Development](https://jeremydmiller.com/2023/08/15/introducing-weasel-for-database-development/) - This model helps the critter stack tools be able to make database migrations on the fly, including: ...

2. [CLAUDE.md - JasperFx/weasel](https://github.com/JasperFx/weasel/blob/master/CLAUDE.md) - Weasel is a low-level database abstraction and schema migration library for .NET, managing database ...

3. [Unrecognized Database Format : r/MSAccess](https://www.reddit.com/r/MSAccess/comments/fsr92b/unrecognized_database_format/) - Modern Access databases stored on fileshare do not work well with windows 10 when multiple users are...

4. [How to Fix the Microsoft Access "Unrecognized Database ...](https://www.youtube.com/watch?v=ZWIPrUrP8oQ) - In this Microsoft Access tutorial, I will show you how to troubleshoot and resolve the "Unrecognized...

5. [Thread: [RESOLVED] unrecognized database format](https://www.vbforums.com/showthread.php?749017-RESOLVED-unrecognized-database-format) - Access 97 File Format using the "Convert Database" option under "Database Utilities" listed under "T...

6. [Sorry for the mistake "data base", English is not my first ...](https://www.facebook.com/groups/it.humor.and.memes/posts/9735654016460295/) - Columns and rows = standardized format. Easily accessed by pretty much everything, including my cat....

7. [unrecognised database format - visual basic](https://www.daniweb.com/programming/software-development/threads/155069/unrecognised-database-format) - is the database .mdb? or mde? or addb? was it created in 97, 2000, 2002/2003 or 2007?

8. [Connecting to a database - forum.mailenable.com](https://www.mailenable.com/forum/viewtopic.php?t=15178) - The email is stored in the flat file format as there is no real advantage in having the messages sto...

9. [Run-Time Error 3343 Unrecognized Database Format](https://support.microsoft.com/en-au/topic/run-time-error-3343-unrecognized-database-format-dbc3ed4f-285d-fa1b-374f-c4eea7643a8c) - This error refers to the frxque32.mdb file and occurs when launching the Queue Monitor. Cause: The f...

10. [How To Implement Https Properly](https://www.websitesthatsell.com.au/web-development/https-implementation/) - In this blog, we'll walk you through how to implement HTTPS the right way, followed by the most comm...

