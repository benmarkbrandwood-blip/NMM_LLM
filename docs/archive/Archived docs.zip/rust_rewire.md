# rust_rewire.md
# NMM_LLM — Rust Core: What Was Done, How to Pull and Rebuild

---

## What Was Done

The `feat/rust-core` branch adds a Rust acceleration layer to the existing Python NMM_LLM project.
`main` is untouched. Nothing was merged. You can always go back.

### What moved to Rust (`native/nmm_core/`)
| Module | File |
|---|---|
| Board state, make/undo move | `src/board.rs` |
| Legal move generation | `src/movegen.rs` |
| Mill detection | `src/mills.rs` |
| Phase detection | `src/phases.rs` |
| D4 symmetry transforms + canonicalisation | `src/symmetry.rs` |
| Heuristic evaluation (integer base) | `src/heuristics.rs` |
| Tactical motif scanning | `src/tactics.rs` |
| Negamax / alpha-beta / iterative deepening + Zobrist TT | `src/search.rs` |
| Transposition table + Zobrist hash | `src/hash.rs` |
| FullGame / Endgame DB key generation | `src/db_probe.rs` |
| Opening / trajectory key generation | `src/opening_probe.rs` |

### Python-side changes (minimal)
- `ai/native_core.py` — new integration seam. Tries `import nmm_core`; falls back to Python engine silently if Rust is unavailable.
- `main.py` — unchanged default. Rust backend is opt-in; Python engine still runs by default.

### What was NOT touched
Web UI, FastAPI/websocket, LLM orchestration, commentary, ChromaDB, trajectory logs,
recorded game formats, blackbox AI training pipelines, `learned_ai/` module.

### Verified results
- 15 Python ↔ Rust parity tests: movegen, mills, phase, D4 symmetry, DB keys, opening keys
- 21 Rust inline unit tests
- 37 existing learned-AI tests — zero regressions
- Smoke game: 720+ plies, zero illegal moves with Rust search active
- Python-only fallback confirmed working

### Benchmark (depth 5)
| Metric | Speedup |
|---|---|
| Search nodes/sec | ~4.6× |
| Wall-clock per move | ~5.2× |
| FullGame DB key gen | ~3.3× |
| Opening canonical key | ~5.8× |

---

## Prerequisites

You need these installed before running anything:

| Tool | Minimum version | Install |
|---|---|---|
| Python | 3.9+ | https://python.org |
| Git | any recent | https://git-scm.com |
| Rust toolchain | stable | https://rustup.rs (install script below will do this) |

> **Note:** The install scripts check for Rust and install it automatically on Linux.
> On Windows, if Rust is missing the script will open https://rustup.rs for you.

---

## Step 1 — Pull the branch

```bash
# If you already have the repo cloned:
cd NMM_LLM
git fetch origin
git checkout feat/rust-core

# If you are cloning fresh:
git clone https://github.com/benmarkbrandwood-blip/NMM_LLM.git
cd NMM_LLM
git checkout feat/rust-core
```

---

## Step 2 — Install everything (one command)

### Linux

```bash
chmod +x install.sh
./install.sh
```

This script:
1. Creates `.venv` if it doesn't exist
2. Installs all Python dependencies (`requirements.txt`, `requirements_learned_ai.txt`)
3. Checks for Rust — installs via rustup if missing
4. Installs `maturin` into the venv
5. Builds the `nmm_core` Rust extension with `maturin develop --release`

### Windows (PowerShell — run as normal user, not admin)

```powershell
.\install.ps1
```

Or via the batch shim:

```cmd
install.bat
```

This does the same steps as Linux. If Rust is not installed, it will open https://rustup.rs in your browser — install Rust, close the installer, then re-run `install.ps1`.

---

## Step 3 — Rebuild the Rust extension only (after editing Rust source)

You only need to rebuild if you change files under `native/nmm_core/src/`.
Normal `git pull` followed by a rebuild is sufficient after any update.

### Linux

```bash
source .venv/bin/activate
bash scripts/build_rust.sh
```

Or manually:

```bash
source .venv/bin/activate
cd native/nmm_core
maturin develop --release
cd ../..
```

### Windows

```powershell
.venv\Scripts\Activate.ps1
.\scripts\build_rust.ps1
```

Or manually:

```powershell
.venv\Scripts\Activate.ps1
Set-Location native\nmm_core
maturin develop --release
Set-Location ..\..
```

---

## Step 4 — Rewire: hook Rust search into GameAI (optional, not yet default)

The Rust backend is wired in `ai/native_core.py` but is not yet the *default* path
inside `GameAI.choose_move()` — this was left as a deliberate follow-up to avoid
touching ChromaDB-coupled code without local testing first.

To activate it manually, find the move-selection call in `game_ai.py` (or wherever
`GameAI.choose_move` / `get_best_move` is defined) and replace the internal search
call with:

```python
from ai.native_core import get_best_move, is_rust_available

# Inside choose_move / get_best_move:
if is_rust_available():
    return get_best_move(board_state, side_to_move, max_depth=6, time_limit_ms=5000)
else:
    # existing Python search fallback
    ...
```

`ai/native_core.py` already handles the board-state conversion, so the call is drop-in.
The `is_rust_available()` check means the game degrades gracefully if the extension
was not built.

---

## Step 5 — Run the game

### Linux

```bash
./run_nmm.sh
```

### Windows

```powershell
.\run_nmm.ps1
```

Or batch:

```cmd
run_nmm.bat
```

---

## Step 6 — Run tests

Activate the venv first:

```bash
# Linux
source .venv/bin/activate

# Windows
.venv\Scripts\Activate.ps1
```

### Parity tests (Python vs Rust, most important)

```bash
python -m pytest tests/test_rust_parity.py -v
python -m pytest tests/test_symmetry_parity.py -v
```

These verify that the Rust implementation produces byte-identical results to Python for:
movegen, mill detection, phase detection, D4 symmetry transforms, canonicalisation,
FullGame/Endgame DB keys, opening canonical keys.

> Tests auto-skip if the Rust extension was not built — they do not crash.

### Full test suite (includes learned-AI tests)

```bash
python -m pytest tests/ -v
```

Expected: 52 total (15 parity + 37 learned-AI), all pass.

### Rust inline unit tests (run inside the crate)

```bash
cd native/nmm_core
cargo test
cd ../..
```

Expected: 21 tests, all pass.

---

## Step 7 — Run benchmarks

```bash
# Search throughput: Python negamax vs Rust negamax (depth 5)
python bench/bench_search.py

# DB key generation throughput
python bench/bench_db.py

# Opening canonical key throughput
python bench/bench_opening.py
```

Each benchmark prints a before/after comparison table.

---

## Step 8 — Smoke game (Rust AI vs Rust AI)

```bash
python bench/smoke_rust_game.py
```

Runs a full AI vs AI game using the Rust search. Every move is validated against
`game.rules`. Expected output: game completes legally with a winner declared.

---

## Fallback: run without Rust

If the Rust extension is not built or fails to import, the game runs normally
using the existing Python engine. You will see this log line at startup:

```
[native_core] Rust backend (nmm_core) not available: ... Falling back to Python engine.
```

No other changes needed. The Python engine is the current default.

---

## File reference

```
NMM_LLM/
  native/nmm_core/          Rust crate (PyO3 + maturin)
    Cargo.toml
    pyproject.toml
    src/
      lib.rs                PyO3 module entry point
      types.rs              Board, Move, Phase, Color
      board.rs              Board state + make_move
      movegen.rs            Legal move generation
      mills.rs              Mill table + detection
      phases.rs             Phase detection
      symmetry.rs           D4 transforms + canonicalisation
      heuristics.rs         Heuristic evaluation
      tactics.rs            Tactical motif scanning
      search.rs             Alpha-beta + iterative deepening
      hash.rs               Zobrist hashing + transposition table
      db_probe.rs           DB key generation (FullGame, Endgame)
      opening_probe.rs      Opening / trajectory key generation

  ai/native_core.py         Python integration seam + fallback
  docs/RUST_INTEGRATION_PLAN.md  Board mapping, D4 arrays, risk register

  install.sh                Linux one-command install
  run_nmm.sh                Linux run script
  install.ps1               Windows one-command install
  install.bat               Windows batch shim
  run_nmm.ps1               Windows run script
  run_nmm.bat               Windows batch shim
  scripts/build_rust.sh     Linux rebuild-Rust-only script
  scripts/build_rust.ps1    Windows rebuild-Rust-only script

  tests/test_rust_parity.py     Python vs Rust parity tests
  tests/test_symmetry_parity.py D4 symmetry parity tests
  bench/bench_search.py     Search throughput benchmark
  bench/bench_db.py         DB key throughput benchmark
  bench/bench_opening.py    Opening key throughput benchmark
  bench/smoke_rust_game.py  Full AI vs AI smoke game
```

---

## Going back to main

```bash
git checkout main
```

`main` was never touched. The Python-only engine is there exactly as it was.
